// JavaScript code can be added here if needed for additional functionalities or interactions.
document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript loaded.');
});
